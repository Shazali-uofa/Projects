# More detail of any AI tool used, including the name, URL, all the input given and all the output received.  
